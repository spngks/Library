package com.smaato.demoapp.activities;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.smaato.demoapp.R;
import com.smaato.soma.BannerView;
import com.smaato.soma.debug.Debugger;

public class BannerFromXmlSample extends ActionBarActivity implements OnClickListener {

	BannerView mBannerView;
	Button loadBanner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_banner_from_xml_sample);
		setTitleColor(Color.WHITE);
		getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#3498db")));
		//Debugger.setDebugMode(Debugger.Level_3);
		mBannerView = (BannerView) findViewById(R.id.bannerView);
		loadBanner = (Button) findViewById(R.id.angry_btn);
		loadBanner.setOnClickListener(BannerFromXmlSample.this);
	}

	@Override
	public void onClick(View v) {
		if (v == loadBanner) {
			mBannerView.asyncLoadNewBanner();
		}
	}
}
