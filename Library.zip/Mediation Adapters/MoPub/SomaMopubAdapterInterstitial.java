package com.smaato.soma.mopubcustomevent;

import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.mopub.mobileads.CustomEventInterstitial;
import com.mopub.mobileads.MoPubErrorCode;
import com.smaato.soma.CrashReportTemplate;
import com.smaato.soma.interstitial.Interstitial;
import com.smaato.soma.interstitial.InterstitialAdListener;

/**
 * Example of MoPub Smaato Interstitial mediation adapter.
 * @author Chouaieb Nabil
 * Updated to support latest MoPub SDK 4.7.0
 * Common for all Publishers
 */
public class SomaMopubAdapterInterstitial extends CustomEventInterstitial implements InterstitialAdListener {

	private Interstitial interstitial;
	private CustomEventInterstitialListener customEventInterstitialListener = null;
	private Handler mHandler;

	@Override
	protected void loadInterstitial(Context context,
									final CustomEventInterstitialListener customEventInterstitialListener, Map<String, Object> localExtras,
									final Map<String, String> serverExtras) {
		// Enable to get full logs
		//Debugger.setDebugMode(Debugger.Level_3);

		mHandler = new Handler(Looper.getMainLooper());
		this.customEventInterstitialListener =customEventInterstitialListener;
		if(interstitial == null){
			interstitial = new Interstitial((Activity) context);
			interstitial.setInterstitialAdListener(this);
		}

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				int publisherId = Integer.parseInt((String) serverExtras.get("publisherId"));
				int adSpaceId = Integer.parseInt((String) serverExtras.get("adSpaceId"));
				interstitial.getAdSettings().setPublisherId(publisherId);
				interstitial.getAdSettings().setAdspaceId(adSpaceId);
				interstitial.asyncLoadNewBanner();

				return null;
			}
		}.execute();

	}

	@Override
	protected void onInvalidate() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void showInterstitial() {
		//interstitial.show();

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						if(interstitial.isInterstitialReady()){
							interstitial.show();
						}
					}
				});

				return null;
			}
		}.execute();



	}

	@Override
	public void onFailedToLoadAd() {

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						customEventInterstitialListener.onInterstitialFailed(MoPubErrorCode.NO_FILL);
					}
				});

				return null;
			}
		}.execute();




	}

	@Override
	public void onReadyToShow() {

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						customEventInterstitialListener.onInterstitialLoaded();

						// comment below line, if you would like to show SmaatoAd, only when calling  mMoPubInterstitial.show() 
						showInterstitial();
					}
				});

				return null;
			}
		}.execute();


	}

	@Override
	public void onWillClose() {

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						customEventInterstitialListener.onInterstitialDismissed();
					}
				});
				return null;
			}
		}.execute();

	}

	@Override
	public void onWillOpenLandingPage() {


		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						customEventInterstitialListener.onInterstitialClicked();
					}
				});

				return null;
			}
		}.execute();

	}

	@Override
	public void onWillShow() {

		new CrashReportTemplate<Void>() {
			@Override
			public Void process() throws Exception {

				mHandler.post(new Runnable() {
					@Override
					public void run() {
						customEventInterstitialListener.onInterstitialShown();
					}
				});

				return null;
			}
		}.execute();

	}

}